escreva("Olá Mundo!"); 
